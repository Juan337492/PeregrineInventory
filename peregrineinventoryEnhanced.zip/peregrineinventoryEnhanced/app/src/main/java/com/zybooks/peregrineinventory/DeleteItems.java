package com.zybooks.peregrineinventory;

import androidx.appcompat.app.AlertDialog;


public class DeleteItems {
	/**
	 * Creates and returns a confirmation dialog for deleting all items.
	 *
	 * @param context The parent activity (ItemsListActivity) that calls this method.
	 * @return An AlertDialog object with "Yes" and "No" options for confirmation.
	 */

    public static AlertDialog doubleButton(final ItemsListActivity context){
		// Create an AlertDialog.Builder instance to build the confirmation dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
		// Set the dialog title, icon, and message
        builder.setTitle(R.string.ad_delete_title)
                .setIcon(R.drawable.delete_all_items)
                .setCancelable(false)
                .setMessage(R.string.ad_delete_msg)

				// Set the "Yes" button to confirm deletion
                .setPositiveButton(R.string.ad_delete_dialog_yes_button, (dialog, arg1) -> {
					ItemsListActivity.YesDeleteItems();
					dialog.cancel();
				})
				// Set the "No" button to cancel deletion
                .setNegativeButton(R.string.ad_delete_dialog_no_button, (dialog, arg1) -> {
					ItemsListActivity.NoDeleteItems();
					dialog.cancel();
				});

		// Create and return the configured AlertDialog
		return builder.create();
    }
}
