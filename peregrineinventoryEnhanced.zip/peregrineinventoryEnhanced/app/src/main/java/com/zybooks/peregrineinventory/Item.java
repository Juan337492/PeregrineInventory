package com.zybooks.peregrineinventory;


public class Item {

    int id;
	String user_email;
    String desc;
    String qty;
	String unit;

    /**
     * Represents an inventory item with details such as description, quantity, and unit.
     * This class provides getter and setter methods to manage item data.
     */

    public Item() {
        super();
    }

    public Item(int i, String email, String description, String quantity, String unit) {
        super();
        this.id = i;
		this.user_email = email;
        this.desc = description;
        this.qty = quantity;
		this.unit = unit;
    }


    /**
     * Constructor to initialize an Item with all attributes, including the ID.
     *
     * i           The unique identifier for the item.
     * email       The email of the user associated with the item.
     * description The description of the item.
     * quantity    The quantity of the item.
     * unit        The unit of measurement for the item.
     */

    public Item(String email, String description, String quantity, String unit) {
		this.user_email = email;
        this.desc = description;
        this.qty = quantity;
		this.unit = unit;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

	public String getUserEmail() {
        return user_email;
    }

    public void setUserEmail(String user_email) {
        this.user_email = user_email;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

	public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }
}
